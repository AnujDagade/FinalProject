package mooc.vandy.java4android.calculator.logic;

public interface Calc {

    public String operate();

}
